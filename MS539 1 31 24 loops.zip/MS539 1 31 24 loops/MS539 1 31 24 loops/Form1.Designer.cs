﻿namespace MS539_1_31_24_loops
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.doLoopBTN = new System.Windows.Forms.Button();
            this.whileLoopBTN = new System.Windows.Forms.Button();
            this.forLoopBTN = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // doLoopBTN
            // 
            this.doLoopBTN.Location = new System.Drawing.Point(55, 60);
            this.doLoopBTN.Name = "doLoopBTN";
            this.doLoopBTN.Size = new System.Drawing.Size(193, 105);
            this.doLoopBTN.TabIndex = 0;
            this.doLoopBTN.Text = "Do loop";
            this.doLoopBTN.UseVisualStyleBackColor = true;
            this.doLoopBTN.Click += new System.EventHandler(this.doLoopBTN_Click);
            // 
            // whileLoopBTN
            // 
            this.whileLoopBTN.Location = new System.Drawing.Point(55, 262);
            this.whileLoopBTN.Name = "whileLoopBTN";
            this.whileLoopBTN.Size = new System.Drawing.Size(197, 108);
            this.whileLoopBTN.TabIndex = 1;
            this.whileLoopBTN.Text = "while loop";
            this.whileLoopBTN.UseVisualStyleBackColor = true;
            this.whileLoopBTN.Click += new System.EventHandler(this.whileLoopBTN_Click);
            // 
            // forLoopBTN
            // 
            this.forLoopBTN.Location = new System.Drawing.Point(55, 473);
            this.forLoopBTN.Name = "forLoopBTN";
            this.forLoopBTN.Size = new System.Drawing.Size(197, 105);
            this.forLoopBTN.TabIndex = 2;
            this.forLoopBTN.Text = "for loop";
            this.forLoopBTN.UseVisualStyleBackColor = true;
            this.forLoopBTN.Click += new System.EventHandler(this.forLoopBTN_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(637, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(147, 32);
            this.label1.TabIndex = 3;
            this.label1.Text = "end loop #";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(643, 173);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 38);
            this.textBox1.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1398, 1005);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.forLoopBTN);
            this.Controls.Add(this.whileLoopBTN);
            this.Controls.Add(this.doLoopBTN);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button doLoopBTN;
        private System.Windows.Forms.Button whileLoopBTN;
        private System.Windows.Forms.Button forLoopBTN;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
    }
}

