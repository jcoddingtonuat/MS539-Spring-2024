﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MS539_1_31_24_loops
{
    public partial class Form1 : Form
    {
        int num1;
        public Form1()
        {
            InitializeComponent();
        }

        private void doLoopBTN_Click(object sender, EventArgs e)
        {
            if (int.TryParse(this.textBox1.Text, out num1))
            {
                int i = 0;
                do
                {
                    MessageBox.Show("i = " + i);
                    i++;
                } while (i < num1);
            }
        }

        private void whileLoopBTN_Click(object sender, EventArgs e)
        {
            if (int.TryParse(this.textBox1.Text, out num1))
            {
                int i = 0;
                while (i < num1)
                {
                    MessageBox.Show("i = " + i);
                    i++;
                };
            }
        }

        private void forLoopBTN_Click(object sender, EventArgs e)
        {
            if (int.TryParse(this.textBox1.Text, out num1))
            {
                for (int i = 0; i < num1; i++)
                {
                    MessageBox.Show("i = " + i);
                }
            }
        }   
    }
}
