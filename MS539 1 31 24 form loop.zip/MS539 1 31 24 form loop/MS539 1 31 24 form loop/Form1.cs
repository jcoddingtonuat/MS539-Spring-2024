﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MS539_1_31_24_form_loop
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void LabelColorBTN_Click(object sender, EventArgs e)
        {
            foreach (Control x in this.Controls) 
            {
                if (x is Label)
                {
                    x.BackColor = Color.White;
                    x.ForeColor = Color.MediumOrchid;
                }
            }
        }

        private void groupColorBTN_Click(object sender, EventArgs e)
        {

            foreach (Control x in this.Controls)
            {
                if (x is TextBox && (string)x.Tag =="Group1")
                {
                    x.ForeColor = Color.MediumSeaGreen; 
                    x.BackColor = Color.Blue;   
                }
                else if (x is Label && (string)x.Tag == "Group1")
                {
                    x.ForeColor = Color.Red;
                    x.BackColor = Color.LightCoral;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label3.BackColor = Color.Black;
            label3.ForeColor = Color.Yellow;
            textBox1.Visible = false;


        }
    }
}
