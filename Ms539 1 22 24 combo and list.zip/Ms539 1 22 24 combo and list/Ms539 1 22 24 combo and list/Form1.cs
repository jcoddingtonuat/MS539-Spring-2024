﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms539_1_22_24_combo_and_list
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           Object selectItem = comboBox1.SelectedItem;
            if (selectItem.ToString() == "CO")
            {
                MessageBox.Show("Better like snow");
                    
            }
            else if (selectItem.ToString() == "AZ")
            {
                MessageBox.Show("Better like really hot");
            }

        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == 0)
            { MessageBox.Show("Must be spring"); 
            }
            else if (listBox1.SelectedIndex == 1)
            {
                MessageBox.Show("It's a sunny day");
            }
        }
    }
}
